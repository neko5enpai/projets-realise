<?php

?>

<!doctype html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>VisageLibraire Index</title>

  <link rel="stylesheet" type="text/css" href="VLstyle.css">
  <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
  
</head>


<body>

	<div id="title_index">
		<h1>VisageLibraire</h1>
	</div>
	<table id="Opts">
		<tr>
			<th>
				<form method="GET" action="Formulaire.php">
					<input class="lien" type="submit" value="Nouveau Profil">
				</form>
			</th>

			<th>
				<form method="GET" action="Recherche.php">
					<input class="lien" type="submit" value="Recherche Profil">
				</form>
			</th>
		</tr>
	</table>


</body>
</html>