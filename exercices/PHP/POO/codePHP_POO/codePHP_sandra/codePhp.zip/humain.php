<?php
class Humain{
    
    private $tete = 1;
    private $bras = 2;
    private $jambes = 2;
    
    public function marcher(){
        echo "Je marche";
    }
    
    public function courir(){
        echo "Je cours";
    }
    
    public function sauter(){
        echo "Je saute";
    }
}

?>