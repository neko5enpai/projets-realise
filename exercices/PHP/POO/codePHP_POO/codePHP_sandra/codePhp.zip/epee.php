<?php
require_once "Arme.php";
class Epee extends Arme{
   
}
?>